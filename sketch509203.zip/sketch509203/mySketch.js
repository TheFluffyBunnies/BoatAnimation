function setup() {
	createCanvas(windowWidth, windowHeight);
	background(100);
	background(33, 180, 196);

}
var x = 50;
var a = 1130;
var r = 1285;
var l = 1080;
var v = 914;
var e = 1100;
function draw() {
 background(140, 202, 255);
 //water
 fill(21, 129, 237);
 rect(0, 400, windowWidth, 800);
 //divider
 fill(181, 175, 175 );
 rect(340, mouseY, 100, 400);
 //boat hull
 fill(89, 61, 61);
 arc( e, 305, 370, 194, 0, PI)
 //boat top
 fill(64, 28, 28);
 rect( v, 255, 371, 50);
 //pole
 fill(225, 192, 118);
 rect( l, 85, 50, 170);
 //Flag
 fill(255, 48, 48);
 triangle( a, 85, a, 185, r, 142.5)
 if (mouseY > 50) {
	   x -= 1.5
		 a -= 1.5
		 r -= 1.5
		 l -= 1.5
		 v -= 1.5
		 e -= 1.5
	  background(140, 202, 255);
   //water
   fill(21, 129, 237);
   rect(0, 400, windowWidth, 800);
   //divider
   fill(181, 175, 175 );
   rect(340, mouseY, 100, 400);
   //boat hull
   fill(89, 61, 61);
   arc( e, 305, 370, 194, 0, PI)
   //boat top
   fill(64, 28, 28);
   rect( v, 255, 371, 50);
   //pole
   fill(225, 192, 118);
   rect( l, 85, 50, 170);
   //Flag
   fill(255, 48, 48);
   triangle( a, 85, a, 185, r, 142.5)
	   //if (e == 240) {
		 //var x = 50;
     //var a = 1130;
     //var r = 1285;
     //var l = 1080;
     //var v = 914;
     //var e = 1100;
	
     //}
 }
}

//finished - submit to children's museum